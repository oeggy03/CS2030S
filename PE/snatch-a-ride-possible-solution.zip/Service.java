public abstract class Service {
  public abstract int computeFare(Request request);
}

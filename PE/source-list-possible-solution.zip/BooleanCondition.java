interface BooleanCondition<T> {
  boolean test(T t); 
}
